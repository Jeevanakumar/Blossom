var add = (a, b) => a + b;
console.log(add(6, 8));
