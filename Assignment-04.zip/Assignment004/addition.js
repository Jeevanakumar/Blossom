function addition(arg1, arg2, arg3)
{
    return arg1 + arg2 + arg3;
}
let result = addition(5, 10, 20);
console.log(result);
