(function()
{
    console.log("Welcome jeevna!!");
})();
